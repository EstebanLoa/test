import React, { Component, useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Login from "../components/Login";

export default class usuarios extends Component {
  render() {
    return (
      <div>
        <Login />
      </div>
    );
  }
}
