import React, { useEffect, useState } from "react";
import { ApiUrl } from "../services/apiServices";
import "../css/style.css";

const ProductForm = () => {
  const [product, setClient] = useState();
  const url = ApiUrl + "listProducts";
  const fetchApi = async () => {
    const response = await fetch(url);
    const responseJSON = await response.json();
    setClient(responseJSON);
  };
  useEffect(() => {
    fetchApi();
  });

  return (
    <div>
      <div class="card-body">
        <div class=" container d-flex flex-row-reverse">
          <ol class="breadcrumb float-sm-left ">
            <li class="breadcrumb-item">
              <a href="./principal">Inicio</a>
            </li>
            <li class="breadcrumb-item">
              <a href="./productsMenu">Menú</a>
            </li>
            <li class="breadcrumb-item active">Añadir Prodcutos</li>
          </ol>
        </div>
        <h3 className="text-center">Productos</h3>
        <div className="col-auto text-center"></div>
      </div>

      <div class="container-fluid content" clear="right">
        <form class="row g-3 formulario text-bg-dark ">
          <h4 class="card-title ">Agregar Ordenes</h4>
          <div class="col-md-1">
            <label>ID</label>
            <div class="position-relative">
              <input
                type="number"
                class="form-control"
                name="ProductId"
                required="requiered"
              />
            </div>
          </div>
          <div class="col-md-4">
            <label>Nombre</label>
            <div class="position-relative">
              <input
                type="text"
                class="form-control"
                name="ProductName"
                required="requiered"
              />
            </div>
          </div>
          <div class="col-md-4">
            <label>Marca</label>
            <div class="position-relative">
              <input
                type="text"
                class="form-control "
                name="ProductBrand"
                required="requiered"
              />
            </div>
          </div>
          <div class="col-md-3">
            <label>Modelo</label>
            <div class="position-relative">
              <input
                type="text"
                class="form-control"
                name="ProductModel"
                required="requiered"
              />
            </div>
          </div>
          <div class="col-md-3">
            <label>Stock</label>
            <div class="position-relative">
              <input
                type="number"
                class="form-control"
                name="ProductStock"
                required="requiered"
              />
            </div>
          </div>
          <div class="col-md-3">
            <label>Precio Distribuidor</label>
            <div class="position-relative">
              <input
                type="number"
                step="any"
                class="form-control"
                name="ProductDealerPrice"
                required="requiered"
              />
            </div>
          </div>
          <div class="col-md-3">
            <label>Sub Total</label>
            <div class="position-relative">
              <input
                type="number"
                step="any"
                class="form-control"
                name="ProductSubTotal"
                required="requiered"
              />
            </div>
          </div>
          <div class="col-12">
            <button
              type="submit"
              value="AddProduct"
              name="accion"
              class="btn btn-success"
            >
              Guardar
            </button>
            <button class="btn">
              <a class=" btn btn-danger" href="./ordersMenu">
                Regresar
              </a>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProductForm;
